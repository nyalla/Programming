var Foodsafe = artifacts.require("./Foodsafe.sol");

module.exports = function(deployer) {

    deployer.deploy(Foodsafe);
  };
  